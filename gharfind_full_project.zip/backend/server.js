import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db.js';

import authRoutes from './routes/authRoutes.js';
import propertyRoutes from './routes/propertyRoutes.js';
import paymentRoutes from './routes/paymentRoutes.js';
import chatRoutes from './routes/chatRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import reviewRoutes from './routes/reviewRoutes.js';
import kycRoutes from './routes/kycRoutes.js';
import agreementRoutes from './routes/agreementRoutes.js';

dotenv.config();
connectDB();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

app.use('/api/auth', authRoutes);
app.use('/api/properties', propertyRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/kyc', kycRoutes);
app.use('/api/agreement', agreementRoutes);

// Socket.io simple logic
const onlineUsers = new Map();
io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);
  socket.on('user_online', (userId) => onlineUsers.set(userId, socket.id));
  socket.on('joinRoom', (roomId) => socket.join(roomId));
  socket.on('sendMessage', (data) => {
    io.to(data.roomId).emit('receiveMessage', data);
    const receiverSocket = onlineUsers.get(data.receiverId);
    if (receiverSocket) {
      io.to(receiverSocket).emit('receive_notification', { senderId: data.senderId, message: data.message || 'New message' });
    }
  });
  socket.on('disconnect', () => {
    for (const [uid, sid] of onlineUsers.entries()) if (sid === socket.id) onlineUsers.delete(uid);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Backend running on ${PORT}`));
