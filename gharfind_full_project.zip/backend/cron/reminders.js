import cron from 'node-cron';
import Payment from '../models/Payment.js';
import sendMail from '../utils/mailer.js';
// daily at 09:00
cron.schedule('0 9 * * *', async () => {
  const today = new Date();
  const due = await Payment.find({ dueDate: { $lte: today }, status: 'Pending' }).populate('userId');
  for (const p of due) {
    await sendMail(p.userId.email, 'Rent due reminder', `Your rent ₹${p.amount} is due.`);
  }
});
export default {};
