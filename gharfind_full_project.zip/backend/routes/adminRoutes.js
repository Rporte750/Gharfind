import express from 'express';
import User from '../models/User.js';
import Property from '../models/Property.js';
import Payment from '../models/Payment.js';
const router = express.Router();
router.get('/summary', async (req, res) => {
  const users = await User.countDocuments();
  const properties = await Property.countDocuments();
  const payments = await Payment.find();
  const revenue = payments.reduce((s,p) => s + (p.amount || 0), 0);
  res.json({ users, properties, revenue });
});
router.get('/users', async (req, res) => res.json(await User.find().select('name email verified kycStatus')));
router.get('/properties', async (req, res) => res.json(await Property.find()));
router.get('/payments', async (req, res) => res.json(await Payment.find().sort({ createdAt: -1 })));
export default router;
