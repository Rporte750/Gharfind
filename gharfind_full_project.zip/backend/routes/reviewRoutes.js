import express from 'express';
import Review from '../models/Review.js';
const router = express.Router();
router.post('/add', async (req, res) => {
  const r = await Review.create(req.body);
  res.json(r);
});
router.get('/:propertyId', async (req, res) => {
  const reviews = await Review.find({ propertyId: req.params.propertyId });
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  res.json({ avg, reviews });
});
export default router;
