import express from 'express';
import Chat from '../models/Chat.js';
const router = express.Router();
router.get('/:roomId', async (req, res) => {
  const chats = await Chat.find({ roomId: req.params.roomId }).sort('timestamp');
  res.json(chats);
});
router.post('/', async (req, res) => {
  const msg = await Chat.create(req.body);
  res.json(msg);
});
export default router;
