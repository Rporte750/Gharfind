import express from 'express';
import { upload } from '../middleware/upload.js';
import User from '../models/User.js';
const router = express.Router();
router.post('/upload', upload.array('kycDocs', 3), async (req, res) => {
  const { userId } = req.body;
  const files = req.files.map(f => `/uploads/${f.filename}`);
  const user = await User.findByIdAndUpdate(userId, { kycDocs: files, kycStatus: 'Pending' }, { new: true });
  res.json({ message: 'KYC submitted', user });
});
router.patch('/verify/:id', async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, { kycStatus: 'Verified', verified: true }, { new: true });
  res.json({ message: 'User verified', user });
});
export default router;
