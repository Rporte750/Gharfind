import mongoose from 'mongoose';
const chatSchema = new mongoose.Schema({
  roomId: String,
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  receiverId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  message: String,
  file: String,
  timestamp: { type: Date, default: Date.now }
});
export default mongoose.model('Chat', chatSchema);
