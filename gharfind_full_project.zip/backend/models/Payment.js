import mongoose from 'mongoose';
const paymentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  propertyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  amount: Number,
  status: String,
  razorpay_order_id: String,
  razorpay_payment_id: String,
  createdAt: { type: Date, default: Date.now },
  dueDate: Date
});
export default mongoose.model('Payment', paymentSchema);
