import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, enum: ['tenant','owner','admin'], default: 'tenant' },
  idProof: String,
  verified: { type: Boolean, default: false },
  kycStatus: { type: String, default: 'NotSubmitted' },
  kycDocs: { type: [String], default: [] }
});
export default mongoose.model('User', userSchema);
