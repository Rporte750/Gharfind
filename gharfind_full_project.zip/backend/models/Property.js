import mongoose from 'mongoose';
const propertySchema = new mongoose.Schema({
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  title: String,
  address: String,
  city: String,
  state: String,
  rent: Number,
  deposit: Number,
  description: String,
  imageUrl: String,
  latitude: Number,
  longitude: Number,
  verified: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});
export default mongoose.model('Property', propertySchema);
