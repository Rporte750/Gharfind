# Gharfind - Full Project (Scaffold)
This scaffold contains frontend and backend starter code for the **Gharfind** house-rent app.
Replace environment values and add your keys before deploying.

## Structure
- backend/  - Node.js + Express API (socket.io ready)
- frontend/ - React app scaffold (Vite or CRA compatible)

## Quick start (local)
1. Backend
   ```
   cd backend
   npm install
   cp .env.example .env    # fill values
   npm run dev
   ```

2. Frontend
   ```
   cd frontend
   npm install
   npm run dev
   ```

## Deployment
- Backend: Render / Railway / Heroku
- Frontend: Vercel / Netlify
- Database: MongoDB Atlas

See each folder's README for details.
