import React, { useEffect, useState } from 'react';
import API from '../api';
export default function AdminDashboard(){
  const [stats,setStats]=useState({});
  useEffect(()=>{ API.get('/admin/summary').then(r=>setStats(r.data)); },[]);
  return (<div className='p-6'><h2 className='text-2xl'>Admin</h2><div className='grid grid-cols-3 gap-4 mt-4'><div className='p-4 border'>Users: {stats.users}</div><div className='p-4 border'>Properties: {stats.properties}</div><div className='p-4 border'>Revenue: ₹{stats.revenue}</div></div></div>);
}
