import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useEffect, useState } from 'react';
import API from '../api';
export default function MapView(){
  const [props,setProps]=useState([]);
  useEffect(()=>{ API.get('/properties').then(r=>setProps(r.data)); },[]);
  return (<div className='h-screen'><MapContainer center={[28.6139,77.209]} zoom={12} className='h-full'><TileLayer url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' /><>{props.map(p=> (<Marker key={p._id} position={[p.latitude||28.61,p.longitude||77.20]}><Popup><div>{p.title}<br/>₹{p.rent}</div></Popup></Marker>))}</></MapContainer></div>);
}
