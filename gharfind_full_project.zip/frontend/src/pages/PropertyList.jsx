import React, { useEffect, useState } from 'react';
import API from '../api';
export default function PropertyList(){
  const [properties, setProperties] = useState([]);
  useEffect(()=>{ API.get('/properties').then(r=>setProperties(r.data)); }, []);
  return (<div className='p-6 grid grid-cols-1 md:grid-cols-3 gap-4'>
    {properties.map(p=>(
      <div key={p._id} className='border p-3 rounded'>
        <h3 className='font-semibold'>{p.title}</h3>
        <p>{p.city} - ₹{p.rent}</p>
      </div>
    ))}
  </div>);
}
