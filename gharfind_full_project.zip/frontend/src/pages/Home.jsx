import { Link } from 'react-router-dom';
export default function Home(){ return (
  <div className='p-6'>
    <h1 className='text-2xl font-bold'>Gharfind - Demo Home</h1>
    <p className='mt-4'>Use the nav to explore pages in the scaffold.</p>
    <Link to='/properties' className='text-blue-600'>View properties</Link>
  </div>
);}
