import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';
import API from '../api';
const socket = io('http://localhost:5000');
export default function ChatRoom(){
  const { roomId } = useParams();
  const [messages,setMessages]=useState([]);
  const [text,setText]=useState('');
  useEffect(()=>{
    socket.emit('joinRoom', roomId);
    API.get(`/chat/${roomId}`).then(r=>setMessages(r.data));
    socket.on('receiveMessage', (m)=> setMessages(prev=>[...prev,m]));
    return ()=> socket.off('receiveMessage');
  },[roomId]);
  const send = async ()=>{ if(!text) return; const msg={roomId, senderId: localStorage.getItem('userId'), message:text}; socket.emit('sendMessage', msg); await API.post('/chat', msg); setText(''); };
  return (<div className='p-4'><div className='h-80 overflow-auto mb-3'>{messages.map((m,i)=>(<div key={i}>{m.message}</div>))}</div><div className='flex gap-2'><input value={text} onChange={e=>setText(e.target.value)} className='flex-1 border p-2' /><button onClick={send} className='bg-teal-600 text-white px-4'>Send</button></div></div>);
}
