import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import PropertyList from './pages/PropertyList';
import ChatRoom from './pages/ChatRoom';
import MapView from './pages/MapView';
import AdminDashboard from './pages/AdminDashboard';
export default function App(){ return (
  <Routes>
    <Route path='/' element={<Home/>} />
    <Route path='/properties' element={<PropertyList/>} />
    <Route path='/chat/:roomId' element={<ChatRoom/>} />
    <Route path='/map' element={<MapView/>} />
    <Route path='/admin' element={<AdminDashboard/>} />
  </Routes>
);}
